/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/7/12
 * Time: 2:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class Job
{
    private int jobNumber, jobPriority,jobSize,maxCPUTime;
    private boolean blocked;
    private int locationInMemory;
  // add time began - to this to calculate max cpu time

    public Job(int jobNumber, int jobPriority, int jobSize, int maxCPUTime)
    {
        this.jobNumber = jobNumber;
        this.jobSize = jobSize;
        this.jobPriority = jobPriority;
        this.maxCPUTime = maxCPUTime;
        this.blocked = false;

    }

    public void setLocationInMemory(int location)
    {
        this.locationInMemory = location;

    }

    public int getLocationInMemory()
    {
       return this.locationInMemory;

    }

    public int getJobNumber() {
        return this.jobNumber;
    }

    public int getJobPriority() {
        return this.jobPriority;
    }

    public int getJobSize() {
        return this.jobSize;
    }

    public int getMaxCPUTime() {
        return this.maxCPUTime;
    }

    public boolean getBlocked(){
        return this.blocked;
    }

    public void setMaxCPUTime(int time) {
        this.maxCPUTime=time;
    }

    public void block(){
        this.blocked=true;
    }

    public void unBlock(){
        this.blocked=false;
    }



}
