import sun.org.mozilla.javascript.internal.ast.WhileLoop;

import java.lang.reflect.Array;
import java.util.LinkedList;

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/7/12
 * Time: 2:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class JobTable
{
    private LinkedList <Job> jobs;
    int numJobs;

    public JobTable()
    {
        jobs = new LinkedList<Job>();
        numJobs=0;
    }

    public void addJobToTable(Job job)
    {
      if(this.isFull()){}// then can't add any more jobs
      else this.jobs.add(job);
        numJobs++;
    }

    public boolean  isFull()
    {
       if(numJobs <50) return false;
       return true;
    }

    public Job getJob(int jobNumber)
    {
           for(int j=0; j<numJobs; j++)
        {

          if(jobs.get(j).getJobNumber()==jobNumber)
              return jobs.get(j);
        }

        return null;
    }

    void remove(int jobNumber)
    {
        jobs.remove(this.getJob(jobNumber));
    }






}
