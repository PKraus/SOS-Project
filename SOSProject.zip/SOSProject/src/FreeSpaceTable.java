import java.util.LinkedList;

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/12/12
 * Time: 3:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class FreeSpaceTable
{
     LinkedList <Entry> entries;

     FreeSpaceTable()
     {
         entries = new LinkedList<Entry>();
         entries.add(new Entry(0,100));
     }

    void deleteFreeSpaceEntry(int location, int size)

    {
       // calculate how to rework the freespace table
    }

    void addFreeSpaceEntry(int location, int size)

    {
         // calculate how to rework the freespace table
        entries.add(new Entry(location,size));
    }

    int findFreeSpace(int size)
    {
       int freeSpaceBegin =-1;
        for(int i = 0;i< entries.size(); i++)
        {
          if(entries.get(i).getSize()>size)
          {
              freeSpaceBegin = entries.get(i).getLocation();
              i=entries.size();
          }
        }

        return freeSpaceBegin;
    }



}
