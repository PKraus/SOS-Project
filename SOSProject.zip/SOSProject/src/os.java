
import java.util.LinkedList;

                    // need to keep track of jobs that are running - need to reprocess time when job is interupted by a service

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/5/12
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */

public class os {

   private static JobTable jobTable;
   private static FreeSpaceTable freeSpaceTable;
   private static LinkedList <Integer> readyQue;
   private static LinkedList <Integer> ioQUe;
   private static int directionOfSwap;
   private static int timeBeganRunning;
   private static final int  memoryToDrum = 1;
   private static final int drumToMemory = 0;
   private static int addressOfJobToBeRun;

    // keep in mind to change the cpu to idle if there are no jobs on the que
    //book keeping function - keep track the need to keep track of job that has stopped running
    // Channel commands siodisk and siodrum are made available to you by the simulator.
    // siodisk has one argument: job number, of type int and passed by value.
    // siodrum has four arguments, all of type int and passed by value:
    // first argument is job number;
    // second argument is job size;
    // third argument is starting core address;
    // fourth argument is interpreted as follows:
    // 1 => move from core (memory) to drum
    // 0 => move from drum to core (memory)
    // The 2 trace procedures allow you to turn the tracing mechanism on and off.
    // The default value is off. WARNING: ontrace() produces a blow-by-blow description
    // of each event and results in an extremely large amount of output.
    // It should be used only as an aid in debugging.
    // Even with the trace off, performance statistics are
    // generated at regular intervals and a diagnostic message appears in case of a crash.
    // In either case, your os need not print anything.

  public static  void startup()
    {
        /// Allows initialization of (static) system variables declared above.
       /// Called once at start of the simulation.
        jobTable = new JobTable();
        readyQue = new LinkedList<Integer>();
        ioQUe = new LinkedList<Integer>();
        freeSpaceTable = new FreeSpaceTable();
        sos.ontrace();
        return;
    }

    // INTERRUPT HANDLERS
    // The following 5 functions are the interrupt handlers. The arguments
    // passed from the environment are detailed with each function below.
    // See RUNNING A JOB, below, for additional information

  public static void Crint (int [] a, int[] p)
    {
        // is the status of the cpu idle or busy
        // Indicates the arrival of a new job on the drum.
        // At call : p [1] = job number
        // p [2] = priority
        // p [3] = job size, K bytes
        // p [4] = max CPU time allowed for job
        // p [5] = current time

        //store the information about the job in class variables
        // want to schedule the job
        jobTable.addJobToTable(new Job(p[1],p[2],p[3],p[4]));
        CPUScheduler(p[1]);
        manageMemory();


             return;

    }


    public static void Dskint (int [] a, int [] p)
    {
        // Disk interrupt.
        // At call : p [5] = current time
        int jobNumber = ioQUe.getFirst();
        ioQUe.removeFirst();
       if(!jobTable.getJob(jobNumber).getBlocked()){
        int time = jobTable.getJob(jobNumber).getMaxCPUTime()-(p[5]-timeBeganRunning) ;
        jobTable.getJob(jobNumber).setMaxCPUTime(time);
       }

        if(!(ioQUe.contains(jobNumber)))
            jobTable.getJob(jobNumber).unBlock();    //make sure it has no more i/o jobs in the que

        if(readyQue.size()== 1){
            setRegisterToRun(a,p);
        }

        if(!ioQUe.isEmpty())
        {
            sos.siodisk(jobTable.getJob(ioQUe.getFirst()).getJobNumber());
            timeBeganRunning = p[5];
        }

        // when i/o is finished   ( after the program says go to do i/o and that i/o is finished
        return;
    }

   public static  void Drmint (int [] a, int [] p)
    {
        // Drum interrupt.
        // At call : p [5] = current time
        //call cpu scheduler
        if(directionOfSwap==drumToMemory)
        {
             setRegisterToRun(a,p);
        }

        // else perhaps memory was free or something?

        return;
    }

    public static void Tro (int [] a, int [] p)
    {
        // Timer-Run-Out.
        // At call : p [5] = current time
        System.out.println("Timer-Run-Out");
        return;
    }

    public static void Svc(int [] a, int [] p)
    {
        // Supervisor call from user program.
        // At call : p [5] = current time
        // a = 5 => job has terminated   // free the memory space and run the next job on the cpu // readyQue.removeFirst()
        // a = 6 => job requests disk i/o
        // a = 7 => job wants to be blocked until all its pending
        // I/O requests are completed
        if(a[0]==5) {

            freeSpaceTable.addFreeSpaceEntry(jobTable.getJob(readyQue.getFirst()).getLocationInMemory() ,jobTable.getJob(readyQue.getFirst()).getJobSize());
            jobTable.remove(readyQue.getFirst());
            readyQue.removeFirst();
            if(readyQue.isEmpty()) a[0]=1;
            else setRegisterToRun(a,p);

            /*also need to free space in free space table */
        }
        if(a[0]==6)
        {
          int time = jobTable.getJob(readyQue.getFirst()).getMaxCPUTime()-(p[5]-timeBeganRunning);
          jobTable.getJob(readyQue.getFirst()).setMaxCPUTime(time);
          setRegisterToRun(a,p);
          ioQUe.add(jobTable.getJob(readyQue.getFirst()).getJobNumber());
          if(ioQUe.size() == 1) sos.siodisk(jobTable.getJob(ioQUe.getFirst()).getJobNumber());
          //else nothing you wait for a diskInt to happen saying i.o is finished

        }
        if(a[0]==7)
        {

            jobTable.getJob(readyQue.getFirst()).block();
            int time = jobTable.getJob(readyQue.getFirst()).getMaxCPUTime()-(p[5]-timeBeganRunning) ;
            jobTable.getJob(readyQue.getFirst()).setMaxCPUTime(time);
            int jobNumber = readyQue.getFirst();
            readyQue.removeFirst();
            readyQue.add(jobNumber);
            if(readyQue.isEmpty()){
                a[0]=1;
            }  else
            {
                setRegisterToRun(a,p);
            }
                        // if doesn't have outstanding i/o don't block it

        }


        return;
    }

   private static void manageMemory()
    {
       // check free space table with the job number.... from the job table
       Job job = jobTable.getJob(readyQue.getFirst());
       addressOfJobToBeRun =  freeSpaceTable.findFreeSpace(job.getJobSize());
       if( addressOfJobToBeRun < 0)
       {

           // no free space available
       }   else {
       // update the free space
           directionOfSwap = drumToMemory;
           jobTable.getJob(readyQue.getFirst()).setLocationInMemory(addressOfJobToBeRun);
           sos.siodrum(job.getJobNumber(),job.getJobSize(),addressOfJobToBeRun,directionOfSwap);
       }




        return;
    }

   private static void CPUScheduler(int jobNumber)
    {

       readyQue.add(jobNumber);


        return;

    }

   private static void setRegisterToRun(int [] a, int []p)
   {
       if(readyQue.size() ==1 && jobTable.getJob(readyQue.getFirst()).getBlocked()==true){
           a[0]=1;
       } else if(!(jobTable.getJob(readyQue.getFirst()).getBlocked()) ){
       a[0]=2;
       p[2]= jobTable.getJob(readyQue.getFirst()).getLocationInMemory();
       p[3]= jobTable.getJob(readyQue.getFirst()).getJobSize()   ;
       p[4] = jobTable.getJob(readyQue.getFirst()).getMaxCPUTime();
       timeBeganRunning = p[5];
       } else // do something if need to move over or something
       {

       }

       return;
   }





}
