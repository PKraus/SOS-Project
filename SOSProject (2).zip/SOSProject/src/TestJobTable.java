import junit.framework.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/7/12
 * Time: 3:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestJobTable {
    @Test
    public void testJobTableConstruction()
    {

        JobTable jobTable = new JobTable();
        Assert.assertNotNull(jobTable);

    }

    @Test
    public void testAddJobToTable()
    {
        JobTable jobTable = new JobTable();
        Job job = new Job(1,2,3,4);

        jobTable.addJobToTable(job);
        jobTable.addJobToTable(job);
        jobTable.addJobToTable(job);

        Assert.assertEquals(job, jobTable.getJob(0));
        Assert.assertEquals(job, jobTable.getJob(1));
        Assert.assertEquals(job, jobTable.getJob(2));
    }

    @Test
    public void testIsFull()
    {
        JobTable jobTable = new JobTable();

        Assert.assertFalse(jobTable.isFull());

        for(int i=0;i<50;i++)
        {
        jobTable.addJobToTable(new Job(1,2,3,4));
        }

        Assert.assertTrue(jobTable.isFull());
     }
}
