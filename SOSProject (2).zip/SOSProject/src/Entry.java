/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/12/12
 * Time: 3:06 PM
 * To change this template use File | Settings | File Templates.
 */
public class Entry {

        private int location, size;

        Entry(int location, int size) {
            this.location = location;
            this.size = size;
        }


         int getSize()
         {
             return this.size;
         }


         int getLocation()
         {
        return this.location;
         }





}
