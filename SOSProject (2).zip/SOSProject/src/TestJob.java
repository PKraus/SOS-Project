import junit.framework.Assert;
import org.junit.Test;

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/7/12
 * Time: 2:52 PM
 * To change this template use File | Settings | File Templates.
 */


public class TestJob
{
    @Test
    public void testJobConstructor()
    {
        Job job = new Job(1,2,3,4);
        Assert.assertNotNull(job);

    }

    @Test
    public void testJobConstructorSetsParts()
    {
        Job job = new Job(1,2,3,4);
        Assert.assertEquals(job.getJobNumber(),1);
        Assert.assertEquals(job.getJobSize(),2);
        Assert.assertEquals(job.getJobPriority(),3);
        Assert.assertEquals(job.getMaxCPUTime(),4);
    }

}
