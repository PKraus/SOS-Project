import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created with IntelliJ IDEA.
 * User: Penina
 * Date: 11/5/12
 * Time: 4:01 PM
 * To change this template use File | Settings | File Templates.
 */

 @RunWith(Suite.class)
 @Suite.SuiteClasses
({
      TestJob.class,
      TestJobTable.class
})

public class Tests
{


}
